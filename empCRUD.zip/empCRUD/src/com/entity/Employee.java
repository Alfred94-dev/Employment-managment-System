package com.entity;

public class Employee {
	private int empID;
	private String eName;
	private String email;
	private String password;
	private String Country;
	
	@Override
	public String toString() {
		return "Employee [empID=" + empID + ", eName=" + eName + ", email=" + email + ", password=" + password
				+ ", Country=" + Country + "]";
	}
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int empID, String eName, String email, String password, String country) {
		super();
		this.empID = empID;
		this.eName = eName;
		this.email = email;
		this.password = password;
		Country = country;
	}
	
	
	public int getEmpID() {
		return empID;
	}
	public void setEmpID(int empID) {
		this.empID = empID;
	}
	public String geteName() {
		return eName;
	}
	public void seteName(String eName) {
		this.eName = eName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCountry() {
		return Country;
	}
	public void setCountry(String country) {
		Country = country;
	}
}
