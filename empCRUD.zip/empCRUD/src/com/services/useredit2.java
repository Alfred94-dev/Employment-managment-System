package com.services;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.EmployeeDaoImpl;
import com.entity.Employee;

@WebServlet("/useredit2")
public class useredit2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public useredit2() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
    	Employee emp = new Employee();
    	
    	emp.setEmpID(Integer.parseInt(request.getParameter("id")));
    	emp.seteName(request.getParameter("name"));
    	emp.setEmail(request.getParameter("email"));
    	emp.setPassword(request.getParameter("password"));
    	emp.setCountry(request.getParameter("country"));
    	
    	
    	EmployeeDaoImpl db = new EmployeeDaoImpl();
    	int i = db.update(emp);
    	if(i > 0)
    	{
    		response.sendRedirect("userload");
    	}
    	
	}

}
