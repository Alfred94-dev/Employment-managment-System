package com.dao;

import java.util.List;

import com.entity.Employee;

public interface EmployeeDao {
	public int update(Employee emp);
	public int delete(int id);
	public int save(Employee e);
	
	public Employee getEmployeeById(int id);
	public List<Employee> getAllEmployees();
}
