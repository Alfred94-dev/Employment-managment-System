package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.entity.Employee;

public class EmployeeDaoImpl implements EmployeeDao{
	
	// he did not tell us to add these variables, I just assume we have to
	public static final String uname = "root";
	public static final String password = "IhtSQLiaehl,lttft!0";
	
	public static final String driver = "com.mysql.jdbc.Driver";
	public static final String dburl = "jdbc:mysql://localhost/test";
	// end of my variable additions

	public static Connection getConnection(){
		Connection conn = null;
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(dburl, uname, password);
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}

	@Override
	public int update(Employee e) {
		Connection conn = getConnection();
		PreparedStatement pst = null;
		try {
			
			pst = conn.prepareStatement("update usercrud set name = ?, email = ?, password = ?, country = ? where id = ?");
			pst.setString(1,  e.geteName());
			pst.setString(2,  e.getEmail());
			pst.setString(3,  e.getPassword());
			pst.setString(4,  e.getCountry());
			pst.setInt(5,  e.getEmpID());
			return pst.executeUpdate();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return 0;
	}

	@Override
	public int delete(int id) {
		Connection conn = getConnection();
		PreparedStatement pst = null;
		try {
			pst = conn.prepareStatement("delete from usercrud where id = ?");
			pst.setInt(1,  id);
			return pst.executeUpdate();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return 0;
	}

	@Override
	public int save(Employee e) {
		Connection conn = getConnection();
		PreparedStatement pst = null;
		try {
			pst = conn.prepareStatement("insert into usercrud(name,password,email,country)values(?,?,?,?)");
			pst.setString(1,  e.geteName());
			pst.setString(2,  e.getPassword());
			pst.setString(3,  e.getEmail());
			pst.setString(4,  e.getCountry());
			return pst.executeUpdate();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return 0;
	}

	@Override
	public Employee getEmployeeById(int id) {
		Connection conn = getConnection();
		PreparedStatement stmt = null;
		try {
			stmt = conn.prepareStatement("select * from usercrud where id=?");
			stmt.setInt(1, id);
			ResultSet result = stmt.executeQuery();
			
			if(result.next())
			{
				Employee emp = new Employee(id,
											result.getString("name"),
											result.getString("email"),
											result.getString("password"),
											result.getString("country"));
				return emp;
			}
			else
				System.out.println("No employee of id " + id + " exists");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Employee> getAllEmployees() {
		
		List<Employee> result = new ArrayList<Employee>();
		Connection conn = getConnection();
		PreparedStatement pst = null;
		
		try {
			pst = conn.prepareStatement("select * from usercrud");
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				result.add(new Employee(rs.getInt(1),		// id
										rs.getString(2),	// name
										rs.getString(3),	// email
										rs.getString(4),	// password
										rs.getString(5)));	// country
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return result;
	}
}
